ABG105_Click_on_Post_TPH()
{
	lr_think_time(thinkTime);

	lr_start_transaction("ABG105_Click_on_Post_TPH");

	sapgui_press_button("Post   (Ctrl+S)", 
		btn2, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1051", 
		END_OPTIONAL);

	sapgui_status_bar_get_text("paramStatusBarText", 
		BEGIN_OPTIONAL, 
			"Recorded status bar text: Document 2510382911 was posted in company code 1001", 
			"AdditionalInfo=sapgui1054", 
		END_OPTIONAL);
	
		
	if(strstr(lr_eval_string("{paramStatusBarText}"),"posted")!=NULL)
{
lr_end_transaction("ABG105_Click_on_Post_TPH",LR_PASS);
      Pass=0;
		fprintf(filename,"ABG105_Click_on_Post_TPH,%s,%s,%s,%s,%s,%d\n",lr_eval_string("{P_UserName}"),lr_eval_string("{P_CustomerNo}"),lr_eval_string("{P_CurrentDate}"),lr_eval_string("{docNumber}"),lr_eval_string("{paramStatusBarText}"),Pass);
		
	}
	else
	{
		lr_end_transaction("ABG105_Click_on_Post_TPH",LR_FAIL);
		Pass=1;
		
		fprintf(filename,"ABG105_Click_on_Post_TPH,%s,%s,%s,%s,%s,%d\n",lr_eval_string("{P_UserName}"),lr_eval_string("{P_CustomerNo}"),lr_eval_string("{P_CurrentDate}"),lr_eval_string("{docNumber}"),lr_eval_string("{paramStatusBarText}"),Pass);
	
	}
	
  lr_save_string("Error","paramStatusBarText");

	
  lr_think_time(ZZ_TT);

	lr_start_transaction("ZZZ103_Click_on_Exit");

	sapgui_press_button("Exit   (Shift+F3)", 
		btn3, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1055", 
		END_OPTIONAL);

	sapgui_select_active_window("wnd[1]");

	sapgui_press_button("Yes", 
		btnSPOP1, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1058", 
		END_OPTIONAL);

	lr_end_transaction("ZZZ103_Click_on_Exit",LR_AUTO);
	
	lr_think_time(pacing);

	
	return 0;
}
