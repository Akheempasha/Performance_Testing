ABG103_Remove_Other_Posting_and_Enter_GLAcc_Details()
{
	lr_think_time(thinkTime);
	
	lr_start_transaction("ABG103_Remove_Other_Posting_and_Enter_GLAcc_Details");

	sapgui_select_tab("Withholding tax", 
		tabpWT1, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1038", 
		END_OPTIONAL);

	lr_end_transaction("ABG103_Remove_Other_Posting_and_Enter_GLAcc_Details",LR_AUTO);

	
	return 0;
}
