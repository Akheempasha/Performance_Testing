ABG104_Click_on_Simulate_and_Enter()
{
	lr_think_time(thinkTime);
	
	lr_start_transaction("ABG104_Click_on_Simulate_and_Enter");

	sapgui_table_fill_data("Table", 
		tblSAPLFWTDWT_DIALOG1, 
		"{data}", 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1042", 
		END_OPTIONAL);

	sapgui_table_fill_data("Table", 
		tblSAPLFSKBTABLE1, 
		"{data_1}", 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1046", 
		END_OPTIONAL);

	sapgui_table_set_focus("(0, 'W/o Cash Dscnt')", 
		tblSAPLFSKBTABLE1, 
		"0", 
		"11", 
		BEGIN_OPTIONAL, 
			"OriginalID=usr/subITEMS:SAPLFSKB:0100/tblSAPLFSKBTABLE/chkACGL_ITEM-XSKRL[11,0]", 
			"AdditionalInfo=sapgui1047", 
		END_OPTIONAL);

	sapgui_press_button("Simulate", 
		btn1, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1048", 
		END_OPTIONAL);

	lr_end_transaction("ABG104_Click_on_Simulate_and_Enter",LR_AUTO);
	
	return 0;
}
