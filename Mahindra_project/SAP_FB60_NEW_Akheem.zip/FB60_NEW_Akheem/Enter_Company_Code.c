Enter_Company_Code()
{
	
	lr_start_transaction("Enter_CompanyCode");
	
	sapgui_select_active_window("wnd[1]");	

	//ses[0]/wnd[1]/usr/lblBKPF-BUKRS
	if(sapgui_is_object_available("usr/lblBKPF-BUKRS",LAST)){
		
	sapgui_set_text("Company Code", 
		"1001", 
		ctxtBKPF1, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1020", 
		END_OPTIONAL);

	sapgui_press_button("Continue   (Enter)", 
		btn5, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1022", 
		END_OPTIONAL);

	lr_end_transaction("Enter_CompanyCode",LR_AUTO);
	lr_output_message("Company_Code_Displayed");
	   }else{
    lr_end_transaction("Enter_CompanyCode",LR_PASS);	
    lr_output_message("Company_Code_Not_Required");
	   }
	return 0;
}
