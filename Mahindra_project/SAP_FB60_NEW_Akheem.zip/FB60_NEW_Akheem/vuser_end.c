vuser_end()
{

	lr_think_time(ZZ_TT);

	lr_start_transaction("ZZZ104_Click_onSignOff");

	sapgui_select_active_window("wnd[0]");

	sapgui_press_button("Log Off   (Shift+F3)", 
		btn3, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1061", 
		END_OPTIONAL);

	sapgui_select_active_window("wnd[1]");

	sapgui_press_button("Yes", 
		btnSPOP1, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1064", 
		END_OPTIONAL);

	lr_end_transaction("ZZZ104_Click_onSignOff",LR_AUTO);
	
	fclose(filename);
	
	lrvtc_disconnect();


	return 0;
}