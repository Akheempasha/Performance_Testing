#ifndef _GLOBALS_H 
#define _GLOBALS_H

//--------------------------------------------------------------------
// Include Files
#include "lrun.h"
#include "as_sapgui.h"
#include "lr_strings.h"
#include "stdio.h"
//--------------------------------------------------------------------
// Global Variables
//char *File1 = "C:\\QK\\FI_ABG_FB60_PassFail2.csv";
//	int Pass ;
//	FILE* filename ;
	
// Global Variables
char *File1 = "C:\\QK\\Passfail\\FI_ABG_FB60_PassFail2.csv";
	int Pass ;
	int ZZ_TT = 10;
	FILE* filename ;
//--------------------------------------------------------------------
// Global Variables


	char *thinkTimeStr;
int thinkTime;
char *pacingStr;
int pacing;

#endif // _GLOBALS_H
