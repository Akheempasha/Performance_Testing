vuser_init()
{
	
	// Connect to VTS
lrvtc_connect("10.218.4.172", 8888, VTOPT_KEEP_ALIVE);
lrvtc_query_column("FB60_New2", 1); // row 1
thinkTimeStr = lr_eval_string("{FB60_New2}");//returns the paramter value in string
thinkTime = atoi(thinkTimeStr); // Convert to int
//lr_output_message("Parsed think time (int) = %d", thinkTime);
//lr_think_time(thinkTime);
lrvtc_query_column("FB60_New2", 2); // row 2
pacingStr = lr_eval_string("{FB60_New2}");
pacing = atoi(pacingStr); // Convert to int
//lr_output_message("Parsed pacing (int) = %d", pacing);
//lr_think_time(pacing);

	if((filename = fopen(File1,"a+"))== NULL) {
		lr_error_message("cannotopen file %s",File1);
	}
	
	lr_eval_string("{P_UserName}"),lr_eval_string("{P_CustomerNo}"),lr_eval_string("{P_CurrentDate}"),lr_eval_string("{docNumber}"),lr_eval_string("{paramStatusBarText}"),
	fprintf(filename,"TimerName,username,supplier,TodayDate,docNumber,paramStatusBarText,PassStatus(0)\n");

	
	lr_start_transaction("ZZZ101_Launch");

	sapgui_open_connection_ex(connection_string1, 
		"RP2-POC", 
		"con[0]");

	sapgui_select_active_connection("con[0]");

	sapgui_select_active_session("ses[0]");

	sapgui_select_active_window("wnd[0]");

	sapgui_window_resize("185", 
		"17", 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui104", 
		END_OPTIONAL);

	lr_end_transaction("ZZZ101_Launch",LR_AUTO);

	lr_think_time(ZZ_TT);

	lr_start_transaction("ZZZ102_Login");

	/*Before running script, enter password in place of asterisks in logon function*/

	sapgui_logon("{P_UserName}", 
		"{P_pwd}", 
		"500", 
		"EN", 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1015", 
		END_OPTIONAL);

	lr_end_transaction("ZZZ102_Login",LR_AUTO);
	
	return 0;
}
