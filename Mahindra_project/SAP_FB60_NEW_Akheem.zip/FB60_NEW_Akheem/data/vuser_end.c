vuser_end()
{

	lr_think_time(17);

	lr_start_transaction("Click_LogOff");

	sapgui_select_active_window("wnd[0]");

	sapgui_press_button("Log Off   (Shift+F3)", 
		btn3, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1061", 
		END_OPTIONAL);

	sapgui_select_active_window("wnd[1]");

	sapgui_press_button("Yes", 
		btnSPOP1, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1064", 
		END_OPTIONAL);

	lr_end_transaction("Click_LogOff",LR_AUTO);

	return 0;
}