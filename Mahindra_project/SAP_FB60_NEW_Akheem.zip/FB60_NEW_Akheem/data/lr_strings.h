#ifndef _LR_STRINGS_H_
#define _LR_STRINGS_H_ 

const char* ctxtBKPF1=
		"usr/ctxtBKPF-BUKRS";

const char* ctxtINVFO1=
		"usr/tabsTS/tabpMAIN/ssubPAGE:SAPLFDCB:0010/ctxtINVFO-ACCNT";

const char* ctxtINVFO2=
		"usr/tabsTS/tabpMAIN/ssubPAGE:SAPLFDCB:0010/ctxtINVFO-BLDAT";

const char* txtINVFO1=
		"usr/tabsTS/tabpMAIN/ssubPAGE:SAPLFDCB:0010/txtINVFO-XBLNR";

const char* txtINVFO2=
		"usr/tabsTS/tabpMAIN/ssubPAGE:SAPLFDCB:0010/txtINVFO-WRBTR";

const char* chkINVFO1=
		"usr/tabsTS/tabpMAIN/ssubPAGE:SAPLFDCB:0010/chkINVFO-XMWST";

const char* cmbINVFO1=
		"usr/tabsTS/tabpMAIN/ssubPAGE:SAPLFDCB:0010/cmbINVFO-MWSKZ";

const char* tabpWT1=
		"usr/tabsTS/tabpWT";

const char* tblSAPLFWTDWT_DIALOG1=
		"usr/tabsTS/tabpWT/ssubPAGE:SAPLFDCB:0080/subSUB_WT:SAPLFWTD:0120/"
		"tblSAPLFWTDWT_DIALOG";

const char* tblSAPLFSKBTABLE1=
		"usr/subITEMS:SAPLFSKB:0100/tblSAPLFSKBTABLE";

const char* btn1=
		"tbar[1]/btn[9]";

const char* btn2=
		"tbar[0]/btn[11]";

const char* btn3=
		"tbar[0]/btn[15]";

const char* btnSPOP1=
		"usr/btnSPOP-OPTION1";

const char* connection_string1=
		"   /SAP_CODEPAGE=1100   /"
		"FULLMENU SNC_PARTNERNAME=\"\" SNC_QOP=-1 /M/10.218.228.13/S/3601/G/"
		"Mahindra /UPDOWNLOAD_CP=2";



#endif // _LR_STRINGS_H_
