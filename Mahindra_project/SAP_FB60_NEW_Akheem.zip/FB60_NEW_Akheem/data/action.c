Action()
{

	lr_start_transaction("Launch_Application");

	sapgui_open_connection_ex(connection_string1, 
		"RP2-POC", 
		"con[0]");

	sapgui_select_active_connection("con[0]");

	sapgui_select_active_session("ses[0]");

	sapgui_select_active_window("wnd[0]");

	sapgui_window_resize("185", 
		"17", 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui104", 
		END_OPTIONAL);

	lr_end_transaction("Launch_Application",LR_AUTO);

	lr_think_time(30);

	lr_start_transaction("Login");

	/*Before running script, enter password in place of asterisks in logon function*/

	sapgui_logon("PERFTEST3615", 
		"*****", 
		"500", 
		"EN", 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1015", 
		END_OPTIONAL);

	lr_end_transaction("Login",LR_AUTO);

	lr_think_time(17);

	lr_start_transaction("Enter_Tcode_FB60");

	sapgui_set_ok_code("fb60", 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1016", 
		END_OPTIONAL);

	sapgui_send_vkey(ENTER, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1017", 
		END_OPTIONAL);

	lr_end_transaction("Enter_Tcode_FB60",LR_AUTO);

	lr_think_time(18);

	lr_start_transaction("Enter_Company_Code");

	sapgui_select_active_window("wnd[1]");

	sapgui_set_text("Company Code", 
		"1001", 
		ctxtBKPF1, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1020", 
		END_OPTIONAL);

	sapgui_send_vkey(ENTER, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1022", 
		END_OPTIONAL);

	lr_end_transaction("Enter_Company_Code",LR_AUTO);

	return 0;
}
