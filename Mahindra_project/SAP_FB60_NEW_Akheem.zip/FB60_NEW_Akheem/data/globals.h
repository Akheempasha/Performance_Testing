#ifndef _GLOBALS_H 
#define _GLOBALS_H

//--------------------------------------------------------------------
// Include Files
#include "lrun.h"
#include "as_sapgui.h"
#include "lr_strings.h"

//--------------------------------------------------------------------
// Global Variables

#endif // _GLOBALS_H
