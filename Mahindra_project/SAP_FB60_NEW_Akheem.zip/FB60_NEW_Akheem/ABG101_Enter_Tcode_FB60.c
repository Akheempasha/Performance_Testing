ABG101_Enter_Tcode_FB60()
{
	lr_think_time(thinkTime);
	
	lr_start_transaction("ABG101_Enter_Tcode_FB60");

	sapgui_set_ok_code("FB60", 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1016", 
		END_OPTIONAL);

	sapgui_send_vkey(ENTER, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1017", 
		END_OPTIONAL);

	lr_end_transaction("ABG101_Enter_Tcode_FB60",LR_AUTO);

/*
	lr_start_transaction("Enter_Company_Code");

	sapgui_select_active_window("wnd[1]");

	sapgui_set_text("Company Code", 
		"1001", 
		ctxtBKPF1, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1020", 
		END_OPTIONAL);

	sapgui_send_vkey(ENTER, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1022", 
		END_OPTIONAL);

	lr_end_transaction("Enter_Company_Code",LR_AUTO);
*/
	return 0;
}
