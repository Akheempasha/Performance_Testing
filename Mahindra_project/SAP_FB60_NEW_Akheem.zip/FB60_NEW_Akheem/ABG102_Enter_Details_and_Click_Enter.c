ABG102_Enter_Details_and_Click_Enter()
{
	lr_think_time(thinkTime);

	lr_start_transaction("ABG102_Enter_Details_and_Click_Enter");

	sapgui_select_active_window("wnd[0]");

	sapgui_set_text("INVFO-ACCNT", 
		"{P_CustomerNo}", 
		ctxtINVFO1, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1025", 
		END_OPTIONAL);

	sapgui_set_text("INVFO-BLDAT", 
		"{P_CurrentDate}", 
		ctxtINVFO2, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1026", 
		END_OPTIONAL);

	sapgui_set_text("Reference", 
		"PTTest{Random}", 
		txtINVFO1, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1027", 
		END_OPTIONAL);

	sapgui_set_text("Amount", 
		"{P_Amount}", 
		txtINVFO2, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1028", 
		END_OPTIONAL);

	sapgui_set_focus(chkINVFO1, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1029", 
		END_OPTIONAL);

	sapgui_set_checkbox("Calculate Tax", 
		"True", 
		chkINVFO1, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1030", 
		END_OPTIONAL);

	sapgui_status_bar_get_text("paramStatusBarText", 
		BEGIN_OPTIONAL, 
			"Recorded status bar text: Vendor DA001 is subject to withholding tax", 
			"AdditionalInfo=sapgui1033", 
		END_OPTIONAL);

//	lr_think_time(5);

	sapgui_set_focus(cmbINVFO1, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1034", 
		END_OPTIONAL);

	sapgui_select_combobox_entry("G0 (Nil GST)", 
		cmbINVFO1, 
		"G0", 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1035", 
		END_OPTIONAL);

	lr_end_transaction("ABG102_Enter_Details_and_Click_Enter", LR_AUTO);

	
/*
	lr_start_transaction("Click_Simulate");

	sapgui_table_fill_data("Table", 
		tblSAPLFWTDWT_DIALOG1, 
		"{data}", 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1042", 
		END_OPTIONAL);

	sapgui_table_fill_data("Table", 
		tblSAPLFSKBTABLE1, 
		"{data_1}", 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1046", 
		END_OPTIONAL);

	sapgui_table_set_focus("(0, 'W/o Cash Dscnt')", 
		tblSAPLFSKBTABLE1, 
		"0", 
		"11", 
		BEGIN_OPTIONAL, 
			"OriginalID=usr/subITEMS:SAPLFSKB:0100/tblSAPLFSKBTABLE/chkACGL_ITEM-XSKRL[11,0]", 
			"AdditionalInfo=sapgui1047", 
		END_OPTIONAL);

	sapgui_press_button("Simulate", 
		btn1, 
		BEGIN_OPTIONAL, 
			"AdditionalInfo=sapgui1048", 
		END_OPTIONAL);

	lr_end_transaction("Click_Simulate",LR_AUTO);
*/
	
	return 0;
}
